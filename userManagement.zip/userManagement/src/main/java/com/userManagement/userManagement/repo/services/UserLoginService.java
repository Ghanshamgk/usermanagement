package com.userManagement.userManagement.repo.services;

import org.springframework.beans.factory.annotation.Autowired;

import com.userManagement.userManagement.model.User;
import com.userManagement.userManagement.repo.UserRepo;
import com.userManagement.userManagement.util.PasswordHashingUtil;

public class UserLoginService {
	private final UserRepo userRepository;

    @Autowired
    public UserLoginService(UserRepo userRepository) {
        this.userRepository = userRepository;
    }

    public User loginUser(String username, String password) {
        User user = userRepository.findByUsername(username);
        if (user != null && PasswordHashingUtil.verifyPassword(password, user.getPassword())) {
            return user;
        } else {
            return null;
        }
    }
}
