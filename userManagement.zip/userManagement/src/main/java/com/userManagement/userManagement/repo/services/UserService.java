package com.userManagement.userManagement.repo.services;

import java.util.List;

import com.userManagement.userManagement.model.User;

public interface UserService {
	User registerUser(String username, String password, String email);
    User loginUser(String username, String password);
    void resetPassword(String username, String newPassword);
    List<User> getAllUsers(int page, int size, String sortBy, String search);

}
