package com.userManagement.userManagement.repo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.userManagement.userManagement.model.User;
import com.userManagement.userManagement.repo.UserRepo;
import com.userManagement.userManagement.util.PasswordHashingUtil;

@Service
public class UserServiseImpl implements UserService{
	
	private final UserRepo userRepository ;
    @Autowired
    public UserServiseImpl(UserRepo userRepository) {
        this.userRepository = userRepository;
    }

	@Override
	public User registerUser(String username, String password, String email) {
        
        if (userRepository.existsByUsername(username) || userRepository.existsByEmail(email)) {
            // Handle registration failure, throw an exception, or return an error response
        }

        // Hash the password before storing it
        String hashedPassword = PasswordHashingUtil.hashPassword(password);

        // Create a new user
        User newUser = new User(username,hashedPassword,email);

        // Save the user to the database
        return (User) userRepository.save(newUser);
	}

	@Override
	public User loginUser(String username, String password) {
		User user = userRepository.findByUsername(username);
        if (user != null && PasswordHashingUtil.verifyPassword(password, user.getPassword())) {
            return user;
        } else {
            return null;
        }
	}

	@Override
	public void resetPassword(String username, String newPassword) {
		 User user = userRepository.findByUsername(username);
	        if (user != null) {
	            String hashedPassword = PasswordHashingUtil.hashPassword(newPassword);
	            user.setPassword(hashedPassword);
	            userRepository.save(user);
	        } else {
	        }
		
	}
	 
	
	 @Override
	    public List<User> getAllUsers(int page, int size, String sortBy, String search) {
	        Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy));
	        return userRepository.findAllByUsernameContainingIgnoreCase(search, pageable).getContent();
	    }
}
