package com.userManagement.userManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.userManagement.userManagement.model.User;
import com.userManagement.userManagement.repo.services.UserService;

@RestController
@RequestMapping("/users")
public class UserController {
	private final UserService userService;
	@Autowired
    public UserController(UserService userService) {
        this.userService = userService;
        
    }

    @PostMapping("/register")
    public User registerUser(@RequestParam String username,
                             @RequestParam String password,
                             @RequestParam String email) {
        return userService.registerUser(username, password, email);
    }

    @PostMapping("/login")
    public User loginUser(@RequestParam String username,
                          @RequestParam String password) {
        return userService.loginUser(username, password);
    }

    @PostMapping("/reset-password")
    public void resetPassword(@RequestParam String username,
                              @RequestParam String newPassword) {
        userService.resetPassword(username, newPassword);
    }

    @GetMapping
    public List<User> getAllUsers(@RequestParam(defaultValue = "0") int page,
                                  @RequestParam(defaultValue = "10") int size,
                                  @RequestParam(defaultValue = "id") String sortBy,
                                  @RequestParam(defaultValue = "") String search) {
        return userService.getAllUsers(page, size, sortBy, search);
    }
}
