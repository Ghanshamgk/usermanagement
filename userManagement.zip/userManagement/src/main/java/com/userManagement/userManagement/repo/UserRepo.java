package com.userManagement.userManagement.repo;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.userManagement.userManagement.model.User;

public interface UserRepo extends JpaRepository{
    User findByUsername(String username);
    boolean existsByUsername(String username);
    boolean existsByEmail(String email);

    
    Page<User> findAllByUsernameContainingIgnoreCase(String username, Pageable pageable);

}
