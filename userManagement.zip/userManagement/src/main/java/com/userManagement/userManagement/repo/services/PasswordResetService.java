package com.userManagement.userManagement.repo.services;

import org.springframework.beans.factory.annotation.Autowired;

import com.userManagement.userManagement.model.User;
import com.userManagement.userManagement.repo.UserRepo;
import com.userManagement.userManagement.util.PasswordHashingUtil;

public class PasswordResetService {
	 private final UserRepo userRepository;

	    @Autowired
	    public PasswordResetService(UserRepo userRepository) {
	        this.userRepository = userRepository;
	    }

	    public void resetPassword(String username, String newPassword) {
	        User user = userRepository.findByUsername(username);
	        if (user != null) {
	            String hashedPassword = PasswordHashingUtil.hashPassword(newPassword);
	            user.setPassword(hashedPassword);
	            userRepository.save(user);
	        } else {
	        }
	    }
    }
