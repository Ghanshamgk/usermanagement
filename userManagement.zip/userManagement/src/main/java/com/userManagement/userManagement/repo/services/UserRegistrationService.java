package com.userManagement.userManagement.repo.services;

import org.springframework.beans.factory.annotation.Autowired;

import com.userManagement.userManagement.model.User;
import com.userManagement.userManagement.repo.UserRepo;
import com.userManagement.userManagement.util.PasswordHashingUtil;

public class UserRegistrationService {
	 private final UserRepo userRepository;
	    @Autowired
	    public UserRegistrationService(UserRepo userRepository) {
	        this.userRepository = userRepository;
	    }

	    public Object registerUser(String username, String password, String email) {
	        if (userRepository.existsByUsername(username) || userRepository.existsByEmail(email)) {
	        }

	        String hashedPassword = PasswordHashingUtil.hashPassword(password);

	        // Create a new user
	        User newUser = new User(username, hashedPassword, email);

	        // Save the user to the database
	        return userRepository.save(newUser);

	    }
}
